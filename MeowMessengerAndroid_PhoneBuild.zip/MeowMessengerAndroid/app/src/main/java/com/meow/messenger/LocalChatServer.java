package com.meow.messenger;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Small LAN-only HTTP chat relay. Keep the app open on the hotspot phone. */
public final class LocalChatServer {
    public static final int PORT = 8765;
    private final Context context;
    private volatile boolean running = false;
    private ServerSocket serverSocket;
    private Thread acceptThread;
    private final Object lock = new Object();
    private final LinkedHashMap<String, Client> clients = new LinkedHashMap<>();
    private final ArrayList<ChatMessage> messages = new ArrayList<>();
    private String hostId = "";
    private long nextSeq = 1;

    private static final class Client {
        String id, name; boolean host, approved; long seen;
        Client(String i, String n, boolean h, boolean a) { id=i; name=n; host=h; approved=a; seen=System.currentTimeMillis(); }
    }
    private static final class ChatMessage {
        long seq, time; String fromId, fromName, text;
        ChatMessage(long s, String id, String name, String t) { seq=s; fromId=id; fromName=name; text=t; time=System.currentTimeMillis(); }
    }

    public LocalChatServer(Context context) { this.context = context.getApplicationContext(); }
    public synchronized void start() throws IOException {
        if (running) return;
        serverSocket = new ServerSocket(PORT, 40, java.net.InetAddress.getByName("0.0.0.0"));
        running = true;
        acceptThread = new Thread(() -> {
            while (running) {
                try {
                    Socket socket = serverSocket.accept();
                    socket.setSoTimeout(8000);
                    new Thread(() -> handle(socket), "MeowHttpClient").start();
                } catch (IOException e) { if (running) android.util.Log.w("MeowServer", "accept", e); }
            }
        }, "MeowLocalServer");
        acceptThread.start();
    }
    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        serverSocket = null;
    }
    public boolean isRunning() { return running; }

    private void handle(Socket socket) {
        try (Socket s = socket; InputStream in = s.getInputStream(); OutputStream out = s.getOutputStream()) {
            ByteArrayOutputStream head = new ByteArrayOutputStream();
            int state=0, b; while ((b=in.read())!=-1) { head.write(b); if ((state==0&&b=='\r')||(state==2&&b=='\r')) state++; else if ((state==1&&b=='\n')||(state==3&&b=='\n')) state++; else state=(b=='\r'?1:0); if (state==4) break; if(head.size()>16384) throw new IOException("header too large"); }
            if (head.size()==0) return;
            String headerText = new String(head.toByteArray(), StandardCharsets.ISO_8859_1);
            String[] lines=headerText.split("\r\n"); String[] first=lines[0].split(" "); if(first.length<2){respond(out,400,"application/json","{}".getBytes(StandardCharsets.UTF_8));return;}
            String method=first[0], target=first[1]; int length=0;
            for(String line:lines){int c=line.indexOf(':');if(c>0&&line.substring(0,c).trim().equalsIgnoreCase("Content-Length")){try{length=Math.min(1024*1024,Integer.parseInt(line.substring(c+1).trim()));}catch(Exception ignored){}}}
            byte[] body=new byte[length]; int got=0; while(got<length){int n=in.read(body,got,length-got);if(n<0)break;got+=n;}
            String path=target.split("\\?",2)[0]; if ("OPTIONS".equals(method)) { respond(out,200,"text/plain; charset=utf-8",new byte[0]); return; } Map<String,String> query=parseParams(target.contains("?")?target.substring(target.indexOf('?')+1):"");
            if ("GET".equals(method) && ("/".equals(path)||"/index.html".equals(path))) { try(InputStream asset=context.getAssets().open("index.html")){respond(out,200,"text/html; charset=utf-8",readAll(asset));} return; }
            if ("GET".equals(method)&&"/health".equals(path)){respondJson(out,200,new JSONObject().put("ok",true).put("port",PORT));return;}
            if ("POST".equals(method)&&"/api/register".equals(path)) { JSONObject req=json(body); String name=req.optString("name","Phone").trim(); if(name.isEmpty())name="Phone"; if(name.length()>32)name=name.substring(0,32); boolean isHost=req.optBoolean("host",false); String id=UUID.randomUUID().toString();
                synchronized(lock){ if(isHost){ if(!hostId.isEmpty())clients.remove(hostId); hostId=id; } boolean approved=isHost||hostId.isEmpty(); clients.put(id,new Client(id,name,isHost,approved)); }
                respondJson(out,200,new JSONObject().put("id",id).put("host",isHost).put("approved",isHost||hostId.isEmpty()).put("server",true));return; }
            if ("GET".equals(method)&&"/api/poll".equals(path)) { String id=query.getOrDefault("id",""); long since=parseLong(query.get("since"),0); JSONObject result=new JSONObject(); JSONArray clientArray=new JSONArray(), msgArray=new JSONArray(); boolean approved=false, isHost=false;
                synchronized(lock){ cleanup(); Client me=clients.get(id); if(me!=null){me.seen=System.currentTimeMillis();approved=me.approved;isHost=me.host;} for(Client c:clients.values()) clientArray.put(new JSONObject().put("id",c.id).put("name",c.name).put("host",c.host).put("approved",c.approved).put("online",System.currentTimeMillis()-c.seen<20000)); for(ChatMessage m:messages) if(m.seq>since) msgArray.put(new JSONObject().put("seq",m.seq).put("fromId",m.fromId).put("fromName",m.fromName).put("text",m.text).put("time",m.time)); }
                result.put("ok",true).put("approved",approved).put("host",isHost).put("clients",clientArray).put("messages",msgArray).put("hostId",hostId); respondJson(out,200,result);return; }
            if ("POST".equals(method)&&"/api/decision".equals(path)) { JSONObject req=json(body); String actor=req.optString("actor",""), targetId=req.optString("clientId",""); boolean accept=req.optBoolean("accept",false); JSONObject result=new JSONObject(); synchronized(lock){ if(!actor.equals(hostId)){respondJson(out,403,new JSONObject().put("ok",false).put("error","Only the hotspot host can accept requests."));return;} Client c=clients.get(targetId); if(c==null||c.host){respondJson(out,404,new JSONObject().put("ok",false).put("error","Device not found."));return;} c.approved=accept; result.put("ok",true).put("approved",accept); } respondJson(out,200,result);return; }
            if ("POST".equals(method)&&"/api/send".equals(path)) { JSONObject req=json(body); String id=req.optString("id",""); String text=req.optString("text","").trim(); JSONObject result=new JSONObject(); synchronized(lock){ Client c=clients.get(id); if(c==null){respondJson(out,403,new JSONObject().put("ok",false).put("error","Please join again."));return;} c.seen=System.currentTimeMillis(); if(!c.approved){respondJson(out,403,new JSONObject().put("ok",false).put("error","Host has not accepted this request yet."));return;} if(text.isEmpty()){respondJson(out,400,new JSONObject().put("ok",false).put("error","Empty message."));return;} if(text.length()>1000)text=text.substring(0,1000); messages.add(new ChatMessage(nextSeq++,c.id,c.name,text)); if(messages.size()>500)messages.remove(0); result.put("ok",true); } respondJson(out,200,result);return; }
            if ("POST".equals(method)&&"/api/leave".equals(path)) { JSONObject req=json(body); synchronized(lock){String id=req.optString("id",""); if(id.equals(hostId))hostId="";clients.remove(id);} respondJson(out,200,new JSONObject().put("ok",true));return; }
            respondJson(out,404,new JSONObject().put("ok",false).put("error","Not found"));
        } catch (Exception e) { android.util.Log.w("MeowServer","request",e); try { OutputStream out=socket.getOutputStream(); respondJson(out,500,new JSONObject().put("ok",false).put("error","Server error")); } catch(Exception ignored){} }
    }
    private void cleanup(){ long cutoff=System.currentTimeMillis()-120000; Iterator<Map.Entry<String,Client>> it=clients.entrySet().iterator();while(it.hasNext()){Map.Entry<String,Client> e=it.next();if(e.getValue().seen<cutoff&&!e.getValue().host){it.remove();}} }
    private static JSONObject json(byte[] b){try{return new JSONObject(new String(b,StandardCharsets.UTF_8));}catch(Exception e){return new JSONObject();}}
    private static long parseLong(String s,long d){try{return Long.parseLong(s);}catch(Exception e){return d;}}
    private static Map<String,String> parseParams(String s){Map<String,String> m=new LinkedHashMap<>();for(String part:s.split("&")){if(part.isEmpty())continue;String[] kv=part.split("=",2);try{m.put(URLDecoder.decode(kv[0],"UTF-8"),kv.length>1?URLDecoder.decode(kv[1],"UTF-8"):"");}catch(Exception ignored){}}return m;}
    private static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
    private static void respondJson(OutputStream out,int code,JSONObject obj)throws IOException{respond(out,code,"application/json; charset=utf-8",obj.toString().getBytes(StandardCharsets.UTF_8));}
    private static void respond(OutputStream out,int code,String type,byte[] body)throws IOException{String label=code==200?"OK":code==400?"Bad Request":code==403?"Forbidden":code==404?"Not Found":"Internal Server Error";String h="HTTP/1.1 "+code+" "+label+"\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+"\r\nConnection: close\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\n\r\n";out.write(h.getBytes(StandardCharsets.ISO_8859_1));out.write(body);out.flush();}
}
