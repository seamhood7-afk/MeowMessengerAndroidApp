Meow Messenger — Offline Local Server Android Project

এটি সরাসরি APK নয়; Android Studio/সমর্থিত Android IDE দিয়ে APK বানানোর source project.

নতুন Local Server ফিচার:
- Hotspot দেওয়া ফোনে Android Meow Messenger অ্যাপ চালু থাকলে সেটি TCP port 8765-এ local HTTP chat server চালায়।
- একই Hotspot-এ যুক্ত অন্য ফোনের Chrome-এ http://192.168.43.1:8765 খুলো। Hotspot gateway আলাদা হলে সঠিক gateway IP ব্যবহার করো।
- পেজে ফোনের নাম দিয়ে “সার্ভারে Join” চাপো। Hotspot host-এর অ্যাপে Request দেখা যাবে; host Accept করলে চ্যাট করা যাবে।
- মেসেজ Hotspot/LAN-এর মধ্যে relay হয়; ইন্টারনেট লাগে না।
- Host অ্যাপ খোলা রাখতে হবে; অ্যাপ বন্ধ করলে embedded server বন্ধ হবে।

APK বানানো:
1. ZIP Extract করে Android IDE-তে MeowMessengerAndroid ফোল্ডার খোলো।
2. Android Gradle Plugin 8.7.3, compileSdk 35 এবং প্রয়োজনীয় SDK/Gradle ডাউনলোড/সেটআপ হতে দাও।
3. Build > Build APK(s) নির্বাচন করো।
4. APK তৈরি হলে ফোনে ইনস্টল করো।

সীমাবদ্ধতা ও নিরাপত্তা:
- এই source project-টি এখানে Android SDK/Gradle দিয়ে compile বা বাস্তব ফোনে পরীক্ষা করা হয়নি; Java/HTML source ও JavaScript syntax পরীক্ষা করা হয়েছে।
- Hotspot IP ফোনভেদে আলাদা হতে পারে। সাধারণ উদাহরণ 192.168.43.1, তবে নেটওয়ার্কের Gateway IP ব্যবহার করতে হবে।
- Server HTTP (TLS ছাড়া) এবং local network-এর জন্য। সংবেদনশীল ব্যক্তিগত তথ্য পাঠিও না; trusted Hotspot-এ ব্যবহার করো।
- Android-এ ব্যাকগ্রাউন্ডে গেলে কিছু ফোন অ্যাপ বন্ধ করে দিতে পারে; চ্যাট চলাকালীন host app খোলা রাখো।
- Browser থেকে সব hotspot client নিজে থেকে enumerate করা যায় না; এই পদ্ধতিতে যারা server page খুলে Join করে তারাই তালিকায় আসবে।
